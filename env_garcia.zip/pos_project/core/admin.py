from django.contrib import admin
from .models import GrupoArticulo, LineaArticulo

admin.site.register(GrupoArticulo)
admin.site.register(LineaArticulo)

# Register your models here.
